﻿
using System.Windows.Forms;

namespace GroceryStoreLogin
{
    public class frmMain : Form
    {
        public frmMain()
        {
            this.Text = "Quản lý cửa hàng tạp hóa";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Width = 600;
            this.Height = 400;
        }
    }
}
